//SarinaKhajavi 40223029
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<ctype.h>
struct sentenceword
{
  char word[30] ;
  char result[30];
};
int main()
{   
    int n;
    printf("enter the number of words in each language");
    scanf("%d",&n);
    struct sentenceword firstinput[n];
    struct sentenceword secondinput[n];
    struct sentenceword final[n];
    struct sentenceword sentence[n];
    char empty1[n];
    char empty2[n];
   
    printf("enter words in each line enter 2 synonym words ,one space between");
    for(int i=0;i<n;i++)
    {
        scanf("%s%c%s%c",&firstinput[i].word,&empty1[i],&secondinput[i].word,&empty2[i]);
    }
    
    for(int x=0;x<n;x++)
      {
      if(strlen(firstinput[x].word)<=strlen(secondinput[x].word))
        strcpy(final[x].result,firstinput[x].word);
        else
        strcpy(final[x].result,secondinput[x].word);
      }

    printf("enter a sentence");
       for(int i=0;i<n;i++)
       {for(int j=0;(sentence[i].word[j]!=' ')&&j<30;j++)
        scanf("%c",&sentence[i].word[j]);
       }
    for(int t=0;t<n;t++)
    {
        for(int w=0;w<n;w++)
        {
            if(!strcmp(sentence[t].word,firstinput[w].word)||!strcmp(sentence[t].word,secondinput[w].word))
            {
                for(int q=0;q<strlen(sentence[t].word);q++)
                {
                if(toupper(sentence[t].word[q])==sentence[t].word[q])
                 sentence[t].word[q]=toupper(final[w].result[q]);
                else
                 sentence[t].word[q]=tolower(final[w].result[q]);
                }
            }
            
        }
    }

    for(int i=0;i<n;i++)
    {
        printf("%s",sentence[i].word);
    }

}